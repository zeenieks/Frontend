# Online Enrollment System Frontend

Boilerplate structure for HTML project.